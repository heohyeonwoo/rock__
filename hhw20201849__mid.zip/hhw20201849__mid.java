import java.util.Scanner;

public class hhw20201849__mid {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in)) {
			String [] str={"가위","바위","보"};
		    while(true) {
		    try{
		        System.out.println("가위바위보 하나빼기 게임 시작~~!");
		        
		        for(int i = 0; i < str.length; i++)
		        	
		        System.out.print(i+"." + str[i]+" / ");
		        System.out.println("3.종료하기");
		        System.out.println("왼속");  
		        int input1=scan.nextInt();
		        if(input1==3)
		        {
		          System.out.println("게임종료"); 
		          break;
		        }        
		        else if(input1!=0 && input1!=1 && input1!=2 )
		          throw new Exception();
		                
		        System.out.println("오른손");  
		        int input2=scan.nextInt();
		        
		        if(input2==3)
		        {
		          System.out.println("게임 끝~~!"); 
		          break;
		        }        
		        else if(input2!=0 && input2!=1 && input2!=2 ) 
		          throw new Exception();
		                
		        int computer1=(int)(Math.random()*3);
		        int computer2=(int)(Math.random()*3);
		        
		        System.out.println("hyeonwoo : 1번["+str[input1]+"],2번["+str[input2]+"]");
		        System.out.println("computer : 1번["+str[computer1]+"],2번["+str[computer2]+"]");
		        System.out.println("둘 중 어떤것을 내시겠습니까?");
		        int input3=scan.nextInt();
		    
		        if(input3!=1 && input3!=2 ) 
		          throw new Exception();
		        
		        int input4=input1;
		        if(input3==2)   
		            input4=input2;
		        
		        int computer4=computer1;
		        if(Math.random()>5)  
		          computer4=computer2;
		        
		        String res="졌습니다.";
		        
		        if(input4==computer4)
		          res="비겼습니다.";
		        else if(input4==0 && computer4==2)
		          res="이겼습니다.";
		        else if(input4==1 && computer4==0)
		          res="이겼습니다.";
		        else if(input4==2 && computer4==1)
		          res="이겼습니다.";
		        
		        System.out.println("승자는!!!");
		        System.out.println("hyeonwoo : "+str[input4]);
		        System.out.println("computer : "+str[computer4]);
		        System.out.println("결과 : "+res);
		        System.out.println("");      
		        }
		        catch(Exception e)
		        {
		        e.printStackTrace();
		        }
	        }
		}
	}
}

