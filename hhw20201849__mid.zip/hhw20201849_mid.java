import java.util.Random;
import java.util.Scanner;

public class hhw20201849_mid {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("가위, 바위, 보 게임 시작! 안내지면 진다 가위 바위 보!!");
		
		Random a = new Random();
		try (Scanner b = new Scanner(System.in)) {
			String hhw = b.nextLine();
			int hyeonwoo = 0;
			int computer = a.nextInt(3);
			
			if (hhw.equals("가위")) {
				hyeonwoo = 0;
            } 
			else if(hhw.equals("바위")) {
				hyeonwoo = 1;
            } 
			else {
			    hyeonwoo = 2; 
            }
			String scissors = "가위";
			String rock = "바위";
			String paper = "보";

			String wooDecision = "none";
			String computerDecision = "none";
					
			if (hyeonwoo == 0) {
				  wooDecision = scissors;
            }           
			else if (hyeonwoo == 1) {
				  wooDecision = rock;
            } 
			else {
				  wooDecision = paper;
            }
			if (computer == 0) {
				  computerDecision = scissors;
			} 
			else if (computer == 1) {
				  computerDecision = rock;
            } 
			else {
				  computerDecision = paper;
            }
			System.out.print("사용자는 " + wooDecision + "을(를) 냈고 ");
			System.out.print("컴퓨터는 " + computerDecision + "을(를) 내서 ");
			if (hyeonwoo == computer) {
				System.out.println("사용자와 컴퓨터는 비겼습니다.");
			} else if (hyeonwoo - computer == 1) {
				System.out.println("사용자가 이겼습니다.");
			} else if (hyeonwoo - computer == -2) {
				System.out.println("사용자가 이겼습니다.");
			} else {
				System.out.println("컴퓨터가 이겼습니다.");
			}
				switch(computer-hyeonwoo) {
			    case 1: case -2:
				System.out.println("hyeonwoo 승");
				break;
			    case 2: case -1:
				System.out.println("computer 승");
				break;
			default :
				System.out.println("비겼습니다.");
				break;	
			}
		}
    }
}

